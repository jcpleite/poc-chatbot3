var http = require('http');
var server = require('./express');


const Eva = require('./app')

var cors = require('cors');


server.options(('/'), (req,res) => {
	res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", 'GET,PUT,POST,DELETE');
    server.use(cors());
})

server.post('/createtoken', Eva.createToken)

server.post('/newMessageClient', Eva.newMessageClient)

server.post('/newMessageAgent', Eva.newMessageAgent)


http.createServer(server)
.listen(process.env.PORT || 3030, function() {
	console.log('Servidor iniciado 3030');
});

 

//var server = app.listen(process.env.PORT || 3000, process.env.IP || "0.0.0.0", function(){
//  var addr = server.address();
//  logger.info("Servidor iniciado em", addr.address + ":" + addr.port);
//});