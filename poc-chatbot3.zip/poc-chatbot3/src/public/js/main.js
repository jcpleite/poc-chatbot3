

var messages = [];
var session;


async function createToken() {
    const validateOpen = document.getElementById("widget-open").checked;

    session = '';
    messages = [];
    var divHistory = document.getElementById('history')
    while (divHistory.firstChild) {
        divHistory.removeChild(divHistory.firstChild)
    }

    if (!validateOpen) {
        return false
    }


    const options = {
        method: 'POST',
    }

    fetch('http://localhost:3030/createToken', options).then((x) => {

        return result = x.json()

    }).then((y) => {

        const options = {
            method: 'POST',
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ "code": "%EVA_WELCOME_MSG" })
        }
        if (y.status == 200) {
            fetch('http://localhost:3030/newMessageAgent', options)
                .then((x) => {
                    return x.json()
                }).then((x) => {

                    session = x.sessionCode

                    messages.push({ id: messages.length + 1, message: x.text, client: false });

                    createElement(messages);

                    if (x.btn) {
                        createButton(x.buttons)
                    }

                })
        }

        if (!y.status == 200) console.error("Erro ao iniciar")
    })
}

async function newMessageClient(e, value) {
    e.preventDefault();

    let text = value


    messages.push({ id: messages.length + 1, message: text, client: true });

    const options = {
        method: 'POST',
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ text, session })
    }

    fetch('http://localhost:3030/newMessageClient', options)
        .then((x) => {
            return x.json()
        }).then((x) => {
            messages.push({ id: messages.length + 1, message: x.text, client: false });

            createElement(messages)

            if (x.btn) {
                createButton(x.buttons)
            }

            var objDiv = document.getElementsByClassName("widget-content");

        })


}

function createElement(history) {

    var divHistory = document.getElementById('history')
    while (divHistory.firstChild) {
        divHistory.removeChild(divHistory.firstChild)
    }
    for (let i = 0; i < history.length; i++) {

        let text = history[i].message

        var divAgent = document.createElement("div");
        var conteudoAgent = document.createElement("p");
        conteudoAgent.innerHTML = text;
        divAgent.appendChild(conteudoAgent)


        if (!history[i].client) {
            divAgent.className = 'interaction agent'

        } else {
            divAgent.className = 'interaction client'
        }

        document.getElementsByClassName("send-message-input")[0].value = ''
        divHistory.appendChild(divAgent)
    }
}



function createButton(button) {


    var divButton = document.getElementById('button-container')

    while (divButton.firstChild) {
        divButton.removeChild(divButton.firstChild)
    }

    var btn = button
    for (let i = 0; i < btn.length; i++) {

        let text = btn[i].name
        let value = btn[i].value

        var buttonAgent = document.createElement("button");

        buttonAgent.innerHTML = text
        buttonAgent.value = value
        buttonAgent.className = 'button-chat'

        buttonAgent.onclick = function () {
            newMessageClient(event, value);
        }



        divButton.appendChild(buttonAgent)
    }


}

//class="interaction client"