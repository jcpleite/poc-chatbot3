const axios = require('axios');

var bearer;


    exports.createToken = (req, res) => {
        const data ={
            grant_type: 'client_credentials',
            client_id: 'sandbox',
            client_secret: 'qxAI8Irsu2NQ8QJxrA05iF15wYwWioRx',
        }

        axios.post('https://keycloak-americas-admin.eva.bot/auth/realms/NTTDATA-EMEAL/protocol/openid-connect/token', data)
        .then((result) =>{

            bearer = result.data.access_token; 
            res.setHeader('Content-Type', 'application/json');
           return res.json({ data: result.data.access_token, status: 200 });

        }).catch((error) => {
            return res.status(400)
        })
    }

    exports.newMessageClient = (req, res) => {
        const { text, session } = req.body;
        
        if(text == ''){
            return false
        }

        const options = {
            headers: {
                'Accept': 'application/json',
                'API-KEY': '6e5f3182-ebe5-11ec-8e01-4201ac1e0009',
                "CHANNEL": 'Web',
                "USER-REF": 'test',
                "LOCALE": 'es-ES',
                "OS": 'Windows',
                'Content-type': 'application/json',
                "Authorization": "Bearer " + bearer,
            }
        }

        const data = {
            text
        }

        axios.post(`https://api-americas-instance1.eva.bot/eva-broker/org/48249918-6f7e-4370-9a46-b2dc572db1a3/env/3dd72d9d-406a-4747-81fe-040556e13550/bot/ad67dc0b-ca52-4ccb-aaa8-8d06f301a2e3/conversations/${session}`, data, options)
        .then((result) => {
            const { answer } = result
            

            if(!!result.data.answers[Array.length - 1].buttons.length){
                validateBtn = true;
            }


            const data = {
                text: result.data.answers[Array.length - 1].content,
                btn: validateBtn,
                buttons: result.data.answers[Array.length - 1].buttons,
            }

            return res.json(data)


        }).catch((error) => {
            return res.send(error).status(400)
        })

    }



    exports.newMessageAgent = (req, res) => {
        const { code } = req.body;
        
        if(code == ''){
            return res.status(400)
        }

        const options = {
            headers: {
                'Accept': 'application/json',
                'API-KEY': '6e5f3182-ebe5-11ec-8e01-4201ac1e0009',
                "CHANNEL": 'Web',
                "USER-REF": 'test',
                "LOCALE": 'es-ES',
                "OS": 'Windows',
                'Content-type': 'application/json',
                "Authorization": "Bearer " + bearer,
            }
        }

        const data = {
            code
        }

        axios.post('https://api-americas-instance1.eva.bot/eva-broker/org/48249918-6f7e-4370-9a46-b2dc572db1a3/env/3dd72d9d-406a-4747-81fe-040556e13550/bot/ad67dc0b-ca52-4ccb-aaa8-8d06f301a2e3/conversations', data, options)
        .then((result) => {
            let validateBtn = false;

            if(!!result.data.answers[Array.length - 1].buttons.length){
                validateBtn = true;
            }


            const data = {
                text: result.data.answers[Array.length - 1].content,
                btn: validateBtn,
                buttons: result.data.answers[Array.length - 1].buttons,
                sessionCode: result.data.sessionCode
            }
            return res.json(data)


        }).catch((error) => {
            return res.send(error).status(400)
        })

    }